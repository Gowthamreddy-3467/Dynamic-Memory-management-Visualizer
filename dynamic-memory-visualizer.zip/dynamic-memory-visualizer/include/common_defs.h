#ifndef COMMON_DEFS_H
#define COMMON_DEFS_H

// Constants
#define MAX_FRAMES 10
#define MAX_PAGES 20
#define PAGE_SIZE 4096

// Memory Frame Structure
typedef struct {
    int frame_number;
    int page_number;
    int process_id;
    int loaded_time;
    int is_free;
} MemoryFrame;

// Page Table Entry
typedef struct {
    int page_number;
    int frame_number;
    int valid;
} PageTableEntry;

#endif