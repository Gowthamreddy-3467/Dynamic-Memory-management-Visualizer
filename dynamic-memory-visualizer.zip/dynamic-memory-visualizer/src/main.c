#include <stdio.h>
#include <stdlib.h>
#include "common_defs.h"
#include "core/memory_manager.h"
#include "core/paging.h"
#include "algorithms/fifo.h"
#include "algorithms/lru.h"
#include "visualization/console_gui.h"
#include "visualization/memory_display.h"
#include "utils/helpers.h"
#include "utils/input_handler.h"

int main() {
    int choice;
    int memory_initialized = 0;
    
    do {
        display_menu();
        choice = get_integer_input("");
        
        switch(choice) {
            case 1: // Initialize Memory
                init_memory();
                init_paging();
                memory_initialized = 1;
                printf("\n✅ Memory system ready!\n");
                press_enter();
                break;
                
            case 2: // Allocate Pages
                if(!memory_initialized) {
                    printf("\n⚠️  Please initialize memory first (Option 1)\n");
                    press_enter();
                    break;
                }
                
                int page_num = get_integer_input("Enter page number (0-19): ");
                int process_id = get_integer_input("Enter process ID: ");
                
                if(page_num >= 0 && page_num < MAX_PAGES) {
                    allocate_page(page_num, process_id);
                    show_memory_visual();
                } else {
                    printf("\n❌ Invalid page number!\n");
                }
                press_enter();
                break;
                
            case 3: // Display Memory State
                if(!memory_initialized) {
                    printf("\n⚠️  Please initialize memory first (Option 1)\n");
                    press_enter();
                    break;
                }
                display_memory();
                press_enter();
                break;
                
            case 4: // Display Page Table
                if(!memory_initialized) {
                    printf("\n⚠️  Please initialize memory first (Option 1)\n");
                    press_enter();
                    break;
                }
                display_page_table();
                press_enter();
                break;
                
            case 5: // Address Translation
                if(!memory_initialized) {
                    printf("\n⚠️  Please initialize memory first (Option 1)\n");
                    press_enter();
                    break;
                }
                int address = get_integer_input("Enter logical address: ");
                translate_address(address);
                press_enter();
                break;
                
            case 6: // Page Replacement Algorithms
                printf("\n=== PAGE REPLACEMENT ALGORITHMS ===\n");
                printf("1. FIFO (First-In-First-Out)\n");
                printf("2. LRU (Least Recently Used)\n");
                int algo_choice = get_integer_input("\nSelect algorithm: ");
                
                if(algo_choice == 1) {
                    printf("\n✅ FIFO algorithm selected\n");
                    // Test FIFO
                    int frame = fifo_replace();
                    printf("Would replace frame: %d\n", frame);
                } else if(algo_choice == 2) {
                    printf("\n✅ LRU algorithm selected\n");
                    // Test LRU
                    int frame = lru_replace();
                    printf("Would replace frame: %d\n", frame);
                } else {
                    printf("\n❌ Invalid choice\n");
                }
                press_enter();
                break;
                
            case 7: // Exit
                printf("\n👋 Exiting program. Goodbye!\n");
                break;
                
            default:
                printf("\n❌ Invalid choice! Please try again.\n");
                press_enter();
        }
    } while(choice != 7);
    
    return 0;
}