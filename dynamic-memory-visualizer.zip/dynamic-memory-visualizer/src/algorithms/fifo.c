#include <stdio.h>
#include "fifo.h"
#include "../../include/common_defs.h"

extern MemoryFrame memory[MAX_FRAMES];

int fifo_replace() {
    int oldest_time = memory[0].loaded_time;
    int oldest_frame = 0;
    
    for(int i = 1; i < MAX_FRAMES; i++) {
        if(memory[i].loaded_time < oldest_time) {
            oldest_time = memory[i].loaded_time;
            oldest_frame = i;
        }
    }
    
    printf("FIFO: Selected frame %d (loaded at time %d)\n", 
           oldest_frame, oldest_time);
    return oldest_frame;
}