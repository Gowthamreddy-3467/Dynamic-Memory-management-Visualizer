#ifndef LRU_H
#define LRU_H

int lru_replace();

#endif