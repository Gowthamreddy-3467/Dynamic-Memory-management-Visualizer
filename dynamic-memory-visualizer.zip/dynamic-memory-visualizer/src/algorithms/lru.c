#include <stdio.h>
#include "lru.h"
#include "../../include/common_defs.h"

extern MemoryFrame memory[MAX_FRAMES];

int lru_replace() {
    int lru_time = memory[0].loaded_time;
    int lru_frame = 0;
    
    for(int i = 1; i < MAX_FRAMES; i++) {
        if(memory[i].loaded_time < lru_time) {
            lru_time = memory[i].loaded_time;
            lru_frame = i;
        }
    }
    
    printf("LRU: Selected frame %d (loaded at time %d)\n", 
           lru_frame, lru_time);
    return lru_frame;
}