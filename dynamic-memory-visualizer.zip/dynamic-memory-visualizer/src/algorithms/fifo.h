#ifndef FIFO_H
#define FIFO_H

int fifo_replace();

#endif