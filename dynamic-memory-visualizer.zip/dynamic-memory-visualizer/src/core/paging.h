#ifndef PAGING_H
#define PAGING_H

void init_paging();
void display_page_table();
int translate_address(int logical_addr);

#endif