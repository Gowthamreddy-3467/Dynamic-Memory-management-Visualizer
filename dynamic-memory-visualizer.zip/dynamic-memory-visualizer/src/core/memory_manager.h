#ifndef MEMORY_MANAGER_H
#define MEMORY_MANAGER_H

void init_memory();
void display_memory();
void allocate_page(int page_num, int process_id);
void free_frame(int frame_num);

#endif