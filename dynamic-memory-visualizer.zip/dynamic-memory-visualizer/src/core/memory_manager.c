#include <stdio.h>
#include <stdlib.h>
#include "memory_manager.h"
#include "../../include/common_defs.h"

MemoryFrame memory[MAX_FRAMES];
PageTableEntry page_table[MAX_PAGES];
int time_counter = 0;
int current_algorithm = 0; // 0=FIFO, 1=LRU

void init_memory() {
    for(int i = 0; i < MAX_FRAMES; i++) {
        memory[i].frame_number = i;
        memory[i].is_free = 1;
        memory[i].page_number = -1;
        memory[i].process_id = -1;
        memory[i].loaded_time = -1;
    }
    
    for(int i = 0; i < MAX_PAGES; i++) {
        page_table[i].page_number = i;
        page_table[i].frame_number = -1;
        page_table[i].valid = 0;
    }
    
    printf("Memory initialized with %d frames\n", MAX_FRAMES);
}

void display_memory() {
    printf("\n========== PHYSICAL MEMORY ==========\n");
    printf("Frame#  Page#  Process  Status\n");
    printf("------  -----  -------  --------\n");
    
    for(int i = 0; i < MAX_FRAMES; i++) {
        if(memory[i].is_free) {
            printf("%6d  %5s  %7s  FREE\n", i, "--", "--");
        } else {
            printf("%6d  %5d  %7d  LOADED\n", 
                   i, memory[i].page_number, memory[i].process_id);
        }
    }
    printf("\n");
}

void allocate_page(int page_num, int process_id) {
    time_counter++;
    
    // Check if already loaded
    if(page_num < MAX_PAGES && page_table[page_num].valid) {
        printf("Page %d is already in frame %d\n", 
               page_num, page_table[page_num].frame_number);
        return;
    }
    
    // Find free frame
    for(int i = 0; i < MAX_FRAMES; i++) {
        if(memory[i].is_free) {
            memory[i].page_number = page_num;
            memory[i].process_id = process_id;
            memory[i].is_free = 0;
            memory[i].loaded_time = time_counter;
            
            if(page_num < MAX_PAGES) {
                page_table[page_num].frame_number = i;
                page_table[page_num].valid = 1;
            }
            
            printf("✓ Page %d loaded into frame %d (Process %d)\n", 
                   page_num, i, process_id);
            return;
        }
    }
    
    // No free frames - need replacement
    printf("Page fault! No free frames available.\n");
}

void free_frame(int frame_num) {
    if(frame_num >= 0 && frame_num < MAX_FRAMES) {
        memory[frame_num].is_free = 1;
        memory[frame_num].page_number = -1;
        memory[frame_num].process_id = -1;
        printf("Frame %d freed\n", frame_num);
    }
}