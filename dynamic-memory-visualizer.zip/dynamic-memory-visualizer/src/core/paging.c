#include <stdio.h>
#include "paging.h"
#include "../../include/common_defs.h"

extern PageTableEntry page_table[MAX_PAGES];

void init_paging() {
    printf("Paging system initialized\n");
    printf("Page size: %d bytes (4KB)\n", PAGE_SIZE);
}

void display_page_table() {
    printf("\n========== PAGE TABLE ==========\n");
    printf("Page#  Frame#  Valid\n");
    printf("-----  ------  -----\n");
    
    for(int i = 0; i < 15 && i < MAX_PAGES; i++) {
        printf("%5d  %6d  %s\n", 
               i, 
               page_table[i].frame_number,
               page_table[i].valid ? "Yes" : "No");
    }
}

int translate_address(int logical_addr) {
    int page_num = logical_addr / PAGE_SIZE;
    int offset = logical_addr % PAGE_SIZE;
    
    printf("\nAddress Translation:\n");
    printf("  Logical address: %d\n", logical_addr);
    printf("  Page number: %d\n", page_num);
    printf("  Offset: %d\n", offset);
    
    if(page_num < MAX_PAGES && page_table[page_num].valid) {
        int physical_addr = page_table[page_num].frame_number * PAGE_SIZE + offset;
        printf("  Physical address: %d\n", physical_addr);
        return physical_addr;
    } else {
        printf("  ⚠️  Page fault! Page not in memory.\n");
        return -1;
    }
}