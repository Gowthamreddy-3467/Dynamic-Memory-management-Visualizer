#include <stdio.h>
#include "memory_display.h"
#include "../../include/common_defs.h"

extern MemoryFrame memory[MAX_FRAMES];

void show_memory_visual() {
    printf("\n");
    printf("┌──────────────────────────────────────┐\n");
    printf("│      MEMORY VISUALIZATION            │\n");
    printf("├──────────────────────────────────────┤\n");
    
    for(int i = 0; i < MAX_FRAMES; i++) {
        printf("│ Frame %2d: ", i);
        if(memory[i].is_free) {
            printf("[  FREE  ]");
        } else {
            printf("[Page %2d ]", memory[i].page_number);
        }
        printf("                    │\n");
    }
    
    printf("└──────────────────────────────────────┘\n");
}