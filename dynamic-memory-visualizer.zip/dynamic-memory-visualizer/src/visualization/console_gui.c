#include <stdio.h>
#include <stdlib.h>
#include "console_gui.h"

void display_menu() {
    clear_screen();
    printf("\n");
    printf("╔══════════════════════════════════════╗\n");
    printf("║   MEMORY MANAGEMENT VISUALIZER       ║\n");
    printf("╚══════════════════════════════════════╝\n\n");
    
    printf("1. Initialize Memory System\n");
    printf("2. Allocate Pages\n");
    printf("3. Display Memory State\n");
    printf("4. Display Page Table\n");
    printf("5. Address Translation\n");
    printf("6. Page Replacement Algorithms\n");
    printf("7. Exit\n\n");
    printf("Enter choice: ");
}

void clear_screen() {
    system("cls");
}