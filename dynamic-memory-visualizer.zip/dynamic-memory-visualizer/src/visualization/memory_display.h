#ifndef MEMORY_DISPLAY_H
#define MEMORY_DISPLAY_H

void show_memory_visual();

#endif