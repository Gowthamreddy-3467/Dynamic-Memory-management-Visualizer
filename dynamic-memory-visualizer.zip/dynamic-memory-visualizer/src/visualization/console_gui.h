#ifndef CONSOLE_GUI_H
#define CONSOLE_GUI_H

void display_menu();
void clear_screen();

#endif