#ifndef INPUT_HANDLER_H
#define INPUT_HANDLER_H

void get_simulation_parameters();

#endif