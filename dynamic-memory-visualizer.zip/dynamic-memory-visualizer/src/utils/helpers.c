#include <stdio.h>
#include <stdlib.h>
#include "helpers.h"

int get_integer_input(const char* prompt) {
    int value;
    printf("%s", prompt);
    scanf("%d", &value);
    return value;
}

void press_enter() {
    printf("\nPress Enter to continue...");
    getchar();
    getchar();
}