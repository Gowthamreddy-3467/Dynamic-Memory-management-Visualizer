#ifndef HELPERS_H
#define HELPERS_H

int get_integer_input(const char* prompt);
void press_enter();

#endif