#include <stdio.h>
#include "input_handler.h"

void get_simulation_parameters() {
    printf("Simulation parameters loaded\n");
}